package bootstrapmodel

type BaseResponse struct {
	Result       bool
	ErrorMessage string
}
