package bootstrapmodel

type SysConf struct {
	Port         int    `json:"port"`
	GlobalConfig string `json:"GlobalConfig"`
}
