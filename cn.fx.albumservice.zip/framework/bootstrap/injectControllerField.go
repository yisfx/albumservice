package bootstrap

import (
	"albumservice/framework/bootstrapmodel"
	"albumservice/framework/utils"
	"reflect"
)

func InjectControllerField(controllerVale *reflect.Value, context *bootstrapmodel.Context, fields map[string]interface{}) *reflect.Value {
	defer utils.HanderError()

	for fieldName, _ := range fields {
		fv := controllerVale.Elem().FieldByName(fieldName)
		if fv.CanSet() {
			fv.Set(reflect.ValueOf(fields[fieldName]))
		}
	}

	fv := controllerVale.Elem().FieldByName("Context")
	if fv.CanSet() {
		fv.Set(reflect.ValueOf(context))
	}
	return controllerVale
}
