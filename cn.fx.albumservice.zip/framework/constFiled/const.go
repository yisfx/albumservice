package constFiled

const (
	Get  = "Get"
	Post = "Post"
)
