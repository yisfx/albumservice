package model

type SysConf struct {
	Port         int    `json:"port"`
	GlobalConfig string `json:"GlobalConfig"`
}
