package albumConst

const (
	MiniExtension = "-mini.jpg"
	MaxExtension  = "-max.jpg"
	OrgExtension  = "-org.jpg"
)
