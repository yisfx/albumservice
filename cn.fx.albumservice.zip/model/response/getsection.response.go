package response

type GetSectionResponse struct{
	Section  []string `json"Section"`
}