package response

import "albumservice/framework/bootstrapmodel"

type AddAlbumResponse struct {
	bootstrapmodel.BaseResponse
}
