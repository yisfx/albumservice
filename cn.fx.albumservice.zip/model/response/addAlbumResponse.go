package response

type AddAlbumResponse struct {
	BaseResponse
}
