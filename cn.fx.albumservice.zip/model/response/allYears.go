package response

type GetAllYearsResponse struct {
	BaseResponse
	AllYears []string
}
