package response

type LoginResponse struct {
	BaseResponse
	LoginToken string
}
