package response

type BaseResponse struct {
	Result       bool
	ErrorMessage string
}
