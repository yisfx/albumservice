package request

type DeEntryImageRequest struct {
	V string
}
