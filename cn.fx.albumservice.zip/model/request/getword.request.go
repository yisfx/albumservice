package request

type GetWordRequest struct {
	Section []string `json:"Section"`
}
