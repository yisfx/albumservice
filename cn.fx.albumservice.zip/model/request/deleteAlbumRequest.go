package request

type DeleteAlbumRequest struct {
	AlbumName string
}
