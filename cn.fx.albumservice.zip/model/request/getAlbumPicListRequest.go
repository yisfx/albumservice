package request

type GetAlbumPicListRequest struct {
	AlbumName string
}
