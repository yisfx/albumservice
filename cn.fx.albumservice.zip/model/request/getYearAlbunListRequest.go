package request

type GetYearAlbumListRequest struct {
	Year string
}
