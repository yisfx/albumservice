package request

type UploadPictureRequest struct {
	AlbumName   string
	PictureName string
}
