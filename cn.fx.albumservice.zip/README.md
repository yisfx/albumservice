# albumservice


## AlbumPath:
> album1
> > * pic1-mini.jpg
> > * pic1-max.jpg
> > * pic1-org.jpg
> > * album.json
> > > {
> > > > - Name  :string=album1
> > > > - Cover :string=pic1
> > > > - Date  :string='2020-01-01'
> > >
> > > }

> album2

shenmedoubuyaoshuo [^a]。


