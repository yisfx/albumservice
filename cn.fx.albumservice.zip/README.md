# albumservice


## AlbumPath:
> album1
> > * pic1-mini.jpg
> > * pic1-max.jpg
> > * pic1-org.jpg
> > * album.json
> > > {
> > > > - Name  :string=album1
> > > > - Cover :string=pic1
> > > > - Date  :string='2020-01-01'
> > >
> > > }

> album2

shenmedoubuyaoshuo [^a]。

[^a]: 什么也不要说,转身直接离开,否则她会像对待一件行李一样对待你
