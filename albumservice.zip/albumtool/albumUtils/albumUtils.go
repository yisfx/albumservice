package albumUtils


func BuildPictureModel(album)
pic := model.Picture{
	Name:     n,
	MiniPath: path.Join(album.Path, n+albumConst.MiniExtension),
	MaxPath:  path.Join(album.Path, n+"-max.jpg"),
	OrgPath:  path.Join(album.Path, n+"-org.jpg"),
	Album:    album.Name,
}

func GetPicName(picName string) string {
	picName = strings.ToLower(picName)
	picName = strings.ReplaceAll(picName, albumConst.MiniExtension, "")
	picName = strings.ReplaceAll(picName, albumConst.MaxExtension, "")
	picName = strings.ReplaceAll(picName, albumConst.OrgExtension, "")
	names := strings.Split(picName, ".")
	return names[0]
}