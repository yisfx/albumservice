package main

import (
	"albumservice/albumtool"
	"albumservice/controller"
	"albumservice/framework"
	model "albumservice/model"
	"fmt"
	"net/http"
	"strconv"
)

func main() {
	conf := *framework.ReadSysConf()
	globalConf := *framework.ReadGlobalConf((conf.GlobalConfig))
	fmt.Println(conf, globalConf)
	manageController := controller.NewAlbumManageController(conf, globalConf)

	framework.Bootstrap(
		*model.NewControllerData("Manage", &manageController),
	)

	// http.HandleFunc("/", func(response http.ResponseWriter, request *http.Request) {
	// 	response.Write([]byte("hello world"))
	// })

	port := ":" + strconv.Itoa(conf.Port)
	fmt.Println("listen at " + port)
	go albumtool.Out()
	http.ListenAndServe(port, nil)
}
