package request

type DeleteAlbumPicRequest struct {
	AlbumName  string
	PicName    string
	DeleteType string
}
