package request

import (
	model "albumservice/model"
)
type AddAlbumRequest struct{
	Album model.Album
}